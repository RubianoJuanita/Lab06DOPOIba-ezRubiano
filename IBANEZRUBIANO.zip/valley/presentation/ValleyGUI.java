package presentation;

import domain.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class ValleyGUI extends JFrame {
    public static final int SIDE = 20;

    public final int SIZE;
    private JButton ticTacButton;
    private JPanel controlPanel;
    private PhotoValley photo;
    private Valley theValley;
    
    // Nuevo elemento para la barra de menú
    private JMenuBar menuBar; 

    private ValleyGUI() {
        theValley = new Valley();
        SIZE = theValley.getSize();
        prepareElements();
        prepareActions();
    }

    private void prepareElements() {
        setTitle("Schelling Valley");
        
        // 1. Crear la barra de menú
        menuBar = new JMenuBar();
        
        // 2. Crear el menú "Opciones"
        JMenu optionsMenu = new JMenu("Opciones");
        
        // 3. Crear los ítems del menú (botones)
        JMenuItem newItem = new JMenuItem("New");
        JMenuItem openItem = new JMenuItem("Open");
        JMenuItem saveAsItem = new JMenuItem("Save As");
        JMenuItem importItem = new JMenuItem("Import");
        JMenuItem exportAsItem = new JMenuItem("Export As");
        JMenuItem exitItem = new JMenuItem("Exit");
        
        // 4. Agregar los ítems al menú "Opciones"
        optionsMenu.add(newItem);
        optionsMenu.add(openItem);
        optionsMenu.add(saveAsItem);
        // Opcional: Agregar un separador visual
        optionsMenu.addSeparator(); 
        optionsMenu.add(importItem);
        optionsMenu.add(exportAsItem);
        optionsMenu.addSeparator();
        optionsMenu.add(exitItem);

        // 5. Agregar el menú "Opciones" a la barra de menú
        menuBar.add(optionsMenu);
        
        // 6. Asignar la barra de menú al JFrame
        setJMenuBar(menuBar); 

        photo = new PhotoValley(this);
        ticTacButton = new JButton("Tic-tac");
        
        setLayout(new BorderLayout());
        add(photo, BorderLayout.CENTER); // Usar CENTER para que la rejilla se vea bien con el menú
        add(ticTacButton, BorderLayout.SOUTH);
        
        // Ajustar el tamaño para acomodar el menú y el cambio a BorderLayout.CENTER
        // El ancho se mantiene, el alto se puede aumentar un poco si es necesario
        setSize(new Dimension(SIDE * SIZE + 15, SIDE * SIZE + 90)); 
        setResizable(false);
        photo.repaint();
    }

    private void prepareActions() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        ticTacButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        ticTacButtonAction();
                    }
                });
        // NOTA: Los JMenuItems no tienen oyentes implementados, según la solicitud.
    }

    private void ticTacButtonAction() {
        theValley.ticTac();
        photo.repaint();
    }

    public Valley gettheValley() {
        return theValley;
    }

    public static void main(String[] args) {
        // Ejecutar la GUI en el hilo de despacho de eventos (es una buena práctica de Swing)
        SwingUtilities.invokeLater(() -> {
            ValleyGUI cg = new ValleyGUI();
            cg.setVisible(true);
        });
    }
}

// ... (La clase PhotoValley se mantiene igual)
class PhotoValley extends JPanel {
    private ValleyGUI gui;

    public PhotoValley(ValleyGUI gui) {
        this.gui = gui;
        setBackground(Color.white);
        setPreferredSize(new Dimension(gui.SIDE * gui.SIZE + 10, gui.SIDE * gui.SIZE + 10));
    }

    public void paintComponent(Graphics g) {
        Valley theValley = gui.gettheValley();
        super.paintComponent(g);

        for (int c = 0; c <= theValley.getSize(); c++) {
            g.drawLine(c * gui.SIDE, 0, c * gui.SIDE, theValley.getSize() * gui.SIDE);
        }
        for (int f = 0; f <= theValley.getSize(); f++) {
            g.drawLine(0, f * gui.SIDE, theValley.getSize() * gui.SIDE, f * gui.SIDE);
        }
        for (int f = 0; f < theValley.getSize(); f++) {
            for (int c = 0; c < theValley.getSize(); c++) {
                if (theValley.getUnit(f, c) != null) {
                    g.setColor(theValley.getUnit(f, c).getColor());
                    if (theValley.getUnit(f, c).shape() == Unit.SQUARE) {
                        g.fillRoundRect(gui.SIDE * c + 1, gui.SIDE * f + 1, gui.SIDE - 2, gui.SIDE - 2, 2, 2);
                    } else {
                        g.fillOval(gui.SIDE * c + 1, gui.SIDE * f + 1, gui.SIDE - 2, gui.SIDE - 2);
                    }
                    // ... (resto del código de dibujo)
                    if (theValley.getUnit(f, c).isAnimal()) {
                        g.setColor(Color.red);
                        if (((Animal) theValley.getUnit(f, c)).getEnergy() >= 50) {
                            g.drawString("u", gui.SIDE * c + 6, gui.SIDE * f + 15);
                        } else {
                            g.drawString("~", gui.SIDE * c + 6, gui.SIDE * f + 17);
                        }
                    }
                }
            }
        }
    }
}